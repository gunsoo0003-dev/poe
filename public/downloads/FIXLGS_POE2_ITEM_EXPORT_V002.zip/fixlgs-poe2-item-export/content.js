(() => {
  if (window.__FIXLGS_POE2_CONTENT__) return;
  window.__FIXLGS_POE2_CONTENT__ = true;

  const itemById = new Map();
  const itemOrder = [];
  let lastCapturedAt = 0;

  const hook = document.createElement("script");
  hook.src = chrome.runtime.getURL("page-hook.js");
  hook.async = false;
  (document.documentElement || document.head).appendChild(hook);
  hook.addEventListener("load", () => hook.remove(), { once: true });

  function stripMarkup(value) {
    return String(value ?? "")
      .replace(/<<[^>]*>>/g, "")
      .replace(/\{[^}]*\}/g, "")
      .replace(/\s+/g, " ")
      .trim();
  }

  function rarityName(frameType) {
    return ({
      0: "Normal",
      1: "Magic",
      2: "Rare",
      3: "Unique",
      4: "Gem",
      5: "Currency",
      6: "Divination Card",
      7: "Quest Item",
      8: "Prophecy",
      9: "Relic"
    })[frameType] || "Rare";
  }

  function formatValueTuple(value) {
    if (Array.isArray(value)) {
      if (Array.isArray(value[0])) return value.map(formatValueTuple).join(", ");
      return stripMarkup(value[0] ?? value.join(" "));
    }
    return stripMarkup(value);
  }

  function formatProperty(prop) {
    if (!prop || !prop.name) return "";
    const values = Array.isArray(prop.values) ? prop.values.map(formatValueTuple).filter(Boolean) : [];
    let name = stripMarkup(prop.name);
    if (name.includes("%0") && values.length) {
      values.forEach(v => { name = name.replace("%0", v); });
      return name;
    }
    if (!values.length) return name;
    return `${name}: ${values.join(", ")}`;
  }

  function replaceIndexedPlaceholders(template, values) {
    let text = stripMarkup(template);
    values.forEach((value, index) => {
      const v = stripMarkup(value);
      text = text
        .replaceAll(`%${index}`, v)
        .replaceAll(`{${index}}`, v);
    });
    return text;
  }

  function modObjectToText(mod) {
    if (mod == null) return "";
    if (typeof mod === "string" || typeof mod === "number") return stripMarkup(mod);
    if (Array.isArray(mod)) {
      return mod.map(modObjectToText).filter(Boolean).join(" ");
    }
    if (typeof mod !== "object") return "";

    const directKeys = [
      "text", "displayText", "display_text", "formatted", "description",
      "line", "modText", "mod_text", "translatedText", "translated_text"
    ];
    for (const key of directKeys) {
      if (typeof mod[key] === "string" && mod[key].trim()) return stripMarkup(mod[key]);
    }

    const values = Array.isArray(mod.values)
      ? mod.values.map(formatValueTuple).filter(Boolean)
      : mod.value != null
        ? [formatValueTuple(mod.value)].filter(Boolean)
        : [];

    const template = [mod.name, mod.template, mod.format, mod.label].find(
      value => typeof value === "string" && value.trim()
    );

    if (template) {
      let text = replaceIndexedPlaceholders(template, values);
      if (values.length && text === stripMarkup(template)) {
        text = `${text}: ${values.join(", ")}`;
      }
      return stripMarkup(text);
    }

    // Kakao trade data can wrap a rendered modifier one level deeper.
    const nestedKeys = ["option", "mod", "data", "value", "translation", "translated"];
    for (const key of nestedKeys) {
      const text = modObjectToText(mod[key]);
      if (text) return text;
    }

    // Never collapse an unknown modifier to "[object Object]". Keep raw data visible
    // during prototype testing so no trade-item information is silently lost.
    try {
      return `[FIXLGS RAW MOD] ${JSON.stringify(mod)}`;
    } catch (_) {
      return "[FIXLGS RAW MOD]";
    }
  }

  function pushBlock(lines, values) {
    const clean = (values || []).map(modObjectToText).filter(Boolean);
    if (!clean.length) return;
    lines.push("--------", ...clean);
  }

  function itemToPobText(entry) {
    const item = entry?.item || entry;
    if (!item || typeof item !== "object") throw new Error("아이템 데이터 없음");

    const lines = [];
    lines.push(`Rarity: ${rarityName(item.frameType)}`);
    if (item.name) lines.push(stripMarkup(item.name));
    if (item.typeLine) lines.push(stripMarkup(item.typeLine));

    const props = (item.properties || []).map(formatProperty).filter(Boolean);
    if (props.length) lines.push("--------", ...props);

    if (item.ilvl != null) lines.push("--------", `Item Level: ${item.ilvl}`);

    const req = (item.requirements || []).map(formatProperty).filter(Boolean);
    if (req.length) lines.push("--------", "Requirements:", ...req.map(v => `  ${v}`));

    if (Array.isArray(item.sockets) && item.sockets.length) {
      const sockets = item.sockets.map(s => {
        const group = Number.isFinite(s.group) ? s.group : 0;
        const attr = stripMarkup(s.attr || "?");
        return { group, attr };
      });
      const grouped = [];
      for (const socket of sockets) {
        if (!grouped[socket.group]) grouped[socket.group] = [];
        grouped[socket.group].push(socket.attr);
      }
      lines.push("--------", `Sockets: ${grouped.filter(Boolean).map(g => g.join("-")).join(" ")}`);
    }

    pushBlock(lines, item.enchantMods);
    pushBlock(lines, item.runeMods);
    pushBlock(lines, item.implicitMods);
    pushBlock(lines, item.fracturedMods);
    pushBlock(lines, item.explicitMods);
    pushBlock(lines, item.craftedMods);
    pushBlock(lines, item.utilityMods);
    pushBlock(lines, item.scourgeMods);

    if (item.corrupted) lines.push("--------", "Corrupted");
    if (item.identified === false) lines.push("--------", "Unidentified");
    if (item.mirrored) lines.push("--------", "Mirrored");
    if (item.duplicated) lines.push("--------", "Split");

    return lines.join("\n");
  }

  async function copyText(text) {
    try {
      await navigator.clipboard.writeText(text);
      return true;
    } catch (_) {
      const area = document.createElement("textarea");
      area.value = text;
      area.style.position = "fixed";
      area.style.opacity = "0";
      document.body.appendChild(area);
      area.focus();
      area.select();
      const ok = document.execCommand("copy");
      area.remove();
      return ok;
    }
  }

  function collectEntries(node, output, seen = new WeakSet(), depth = 0) {
    if (!node || depth > 7) return;
    if (typeof node !== "object") return;
    if (seen.has(node)) return;
    seen.add(node);

    if (Array.isArray(node)) {
      for (const child of node) collectEntries(child, output, seen, depth + 1);
      return;
    }

    if (node.item && typeof node.item === "object") {
      const item = node.item;
      if (item.typeLine || item.name || item.explicitMods || item.properties) {
        output.push(node);
      }
    }

    for (const value of Object.values(node)) collectEntries(value, output, seen, depth + 1);
  }

  function ingest(payload) {
    const found = [];
    collectEntries(payload, found);
    let added = 0;

    for (const entry of found) {
      const id = String(entry.id || entry.item?.id || entry.listing?.id || "").trim();
      const key = id || `idx:${itemOrder.length}`;
      if (!itemById.has(key)) {
        itemById.set(key, entry);
        itemOrder.push(entry);
        added++;
      } else {
        itemById.set(key, entry);
      }
    }

    if (added) {
      lastCapturedAt = Date.now();
      updateStatus();
      scheduleDecorate();
    }
  }

  window.addEventListener("message", event => {
    if (event.source !== window) return;
    const data = event.data;
    if (!data || data.source !== "FIXLGS_POE2_PAGE" || data.type !== "FIXLGS_TRADE_JSON") return;
    ingest(data.payload);
  });

  function rowId(row) {
    const candidates = [
      row.getAttribute("data-id"),
      row.id,
      row.querySelector("[data-id]")?.getAttribute("data-id"),
      row.querySelector("[id]")?.id,
    ].filter(Boolean);
    for (const value of candidates) {
      const v = String(value).replace(/^result-/, "").trim();
      if (itemById.has(v)) return v;
    }
    return "";
  }

  function likelyRows() {
    const selectors = [
      ".resultset .row",
      ".resultset > .result",
      ".resultset [data-id]",
      ".search-results .row",
      "[class*=resultset] [class*=row]"
    ];
    const set = new Set();
    for (const selector of selectors) {
      document.querySelectorAll(selector).forEach(el => {
        if (!(el instanceof HTMLElement)) return;
        const text = el.innerText || "";
        if (text.length < 20) return;
        if (el.querySelector(".fixlgs-export-button")) return;
        set.add(el);
      });
    }
    return [...set];
  }

  function entryForRow(row, index) {
    const id = rowId(row);
    if (id && itemById.has(id)) return itemById.get(id);
    return itemOrder[index] || null;
  }

  function setButtonState(button, state, text) {
    button.dataset.state = state;
    button.textContent = text;
    setTimeout(() => {
      if (button.isConnected) {
        button.dataset.state = "";
        button.textContent = "FIXLGS EXPORT";
      }
    }, 1600);
  }

  async function exportEntry(entry, button) {
    try {
      const text = itemToPobText(entry);
      if (!text || text.length < 20) throw new Error("변환 결과 없음");
      const ok = await copyText(text);
      if (!ok) throw new Error("클립보드 실패");
      setButtonState(button, "ok", "COPIED ✓");
    } catch (error) {
      console.warn("[FIXLGS] export failed", error, entry);
      setButtonState(button, "error", "EXPORT ERROR");
    }
  }

  function decorate() {
    const rows = likelyRows();
    rows.forEach((row, index) => {
      if (row.querySelector(":scope > .fixlgs-export-button")) return;
      const button = document.createElement("button");
      button.type = "button";
      button.className = "fixlgs-export-button";
      button.textContent = "FIXLGS EXPORT";
      button.title = "이 매물 아이템을 FIXLGS / PoB 형식으로 복사";
      button.addEventListener("click", event => {
        event.preventDefault();
        event.stopPropagation();
        const entry = entryForRow(row, index);
        if (!entry) {
          setButtonState(button, "error", "DATA WAIT");
          return;
        }
        exportEntry(entry, button);
      });
      row.prepend(button);
    });
    updateStatus();
  }

  let decorateTimer = null;
  function scheduleDecorate() {
    clearTimeout(decorateTimer);
    decorateTimer = setTimeout(decorate, 80);
  }

  function ensureStatus() {
    if (!document.body) return null;
    let status = document.getElementById("fixlgs-export-status");
    if (status) return status;
    status = document.createElement("div");
    status.id = "fixlgs-export-status";
    status.innerHTML = `<span class="fixlgs-status-text">FIXLGS: waiting</span><button type="button">TEST #1</button>`;
    status.querySelector("button").addEventListener("click", async () => {
      const first = itemOrder[0];
      const button = status.querySelector("button");
      if (!first) {
        button.textContent = "NO DATA";
        setTimeout(() => button.textContent = "TEST #1", 1200);
        return;
      }
      try {
        await copyText(itemToPobText(first));
        button.textContent = "COPIED";
      } catch (_) {
        button.textContent = "ERROR";
      }
      setTimeout(() => button.textContent = "TEST #1", 1200);
    });
    document.body.appendChild(status);
    return status;
  }

  function updateStatus() {
    const status = ensureStatus();
    if (!status) return;
    const text = status.querySelector(".fixlgs-status-text");
    const age = lastCapturedAt ? Math.max(0, Math.floor((Date.now() - lastCapturedAt) / 1000)) : null;
    text.textContent = itemOrder.length
      ? `FIXLGS: ${itemOrder.length} item${itemOrder.length === 1 ? "" : "s"} captured${age != null ? ` · ${age}s` : ""}`
      : "FIXLGS: waiting for trade data";
  }

  const observer = new MutationObserver(scheduleDecorate);
  const start = () => {
    if (!document.documentElement) return setTimeout(start, 20);
    observer.observe(document.documentElement, { childList: true, subtree: true });
    scheduleDecorate();
    setInterval(updateStatus, 1000);
  };
  start();
})();
