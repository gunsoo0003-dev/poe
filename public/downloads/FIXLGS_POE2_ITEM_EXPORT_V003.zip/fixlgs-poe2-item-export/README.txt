FIXLGS POE2 Item Export V003

[필수]
- Google Chrome에서 설치하고 POE2 거래소도 Google Chrome에서 열어 주세요.
- 다른 브라우저에 설치한 확장프로그램은 Chrome 거래소 페이지에서 작동하지 않습니다.

[개발 테스트 설치]
1. 이 폴더가 들어 있는 ZIP의 압축을 풉니다.
2. Chrome 주소창에 chrome://extensions 입력
3. 우측 상단 '개발자 모드' 켜기
4. '압축 해제된 확장 프로그램을 로드합니다' 클릭
5. manifest.json이 있는 이 폴더 선택
6. Chrome에서 POE2 거래소를 열고 새로고침

[사용]
1. 거래소에서 원하는 아이템을 검색합니다.
2. 해당 매물의 FIXLGS EXPORT 버튼을 누릅니다.
3. COPIED 표시가 나오면 아이템 정보가 클립보드에 복사된 상태입니다.
4. FIXLGS /pob Simulation 장비 슬롯에 붙여넣습니다.

[V003 보완]
- 소켓이 '?'로 나오던 문제 수정: rune 소켓은 S로 출력
- socketedItems가 실제 룬/소켓 아이템인 경우 이름도 보존
- grantedSkills(스킬 부여) 출력
- additionalProperties 출력
- rune/enchant/implicit/fractured/crafted 등 mod 종류 보존
- 알려지지 않은 *Mods 배열도 누락 없이 출력
- Corrupted / Unidentified / Mirrored / Split / Replica / Synthesised / Veiled 상태 보존
- 행 번호만으로 매물을 매칭하지 않도록 안전성 강화
