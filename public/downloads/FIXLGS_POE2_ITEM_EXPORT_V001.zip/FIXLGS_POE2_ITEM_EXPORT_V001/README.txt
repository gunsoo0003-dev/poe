FIXLGS POE2 Item Export V001 (Prototype)

목적
- POE2 거래소 검색 결과에서 개별 매물의 아이템 JSON을 브라우저 안에서 감지
- 각 매물에 FIXLGS EXPORT 버튼 추가
- 클릭한 아이템을 PoB 스타일 텍스트로 클립보드 복사

설치
1. 이 ZIP을 원하는 폴더에 압축 해제합니다.
2. Chrome 주소창에 chrome://extensions 입력
3. 오른쪽 위 '개발자 모드' 켜기
4. '압축 해제된 확장 프로그램을 로드합니다' 클릭
5. manifest.json이 들어 있는 FIXLGS_POE2_ITEM_EXPORT_V001 폴더 선택
6. POE2 거래소 페이지 새로고침

테스트
- 거래소 검색 결과 우측 아래에 'FIXLGS: N items captured' 표시가 나오면 JSON 감지 성공입니다.
- 개별 매물의 'FIXLGS EXPORT' 클릭 후 메모장 등에 Ctrl+V 해보세요.
- 버튼이 안 붙어도 우측 아래 TEST #1을 누르면 첫 번째 감지 아이템을 복사할 수 있습니다.

주의
- V001은 실제 카카오 거래소 DOM/API 구조 확인용 프로토타입입니다.
- 거래소 사이트 구조 변경 시 셀렉터/데이터 매핑을 조정해야 할 수 있습니다.
